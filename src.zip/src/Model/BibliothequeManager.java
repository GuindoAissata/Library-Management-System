package Model;
import java.io.*;
import java.util.*;

/**
 * 
 */
public class BibliothequeManager {

    /**
     * Default constructor
     */
    public BibliothequeManager() {
    }

    /**
     * 
     */
    public Set<Emprunt> List_Emprunt;

    /**
     * 
     */
    public  Set<Document> List_Document;

    /**
     * 
     */
    public Set<Adherent> List_Adherent;

    /**
     * @param d
     */
    public void Emprunt(Document d) {
        // TODO implement here
    }

    /**
     * @param d
     */
    public void Retour(Document d) {
        // TODO implement here
    }

}