
//package Model;
//import java.io.*;
//import java.util.*;

/**
 * 
 */
//public class Main Application {

    /**
     * Default constructor
     */
    //public Main Application() {
    //}

    /**
     * @param args 
     * @return
     */
    //public void main(String args) {
        // TODO implement here
       // return null;
    //}

    /**
     * @return
     */
    //public void Lancer_interface() {
        // TODO implement here
       // return null;
    //}

//}
