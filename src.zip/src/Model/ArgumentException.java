package Model;

public class ArgumentException extends Exception {
    String message;
    public ArgumentException(String m){ message = m ; }
    
}
